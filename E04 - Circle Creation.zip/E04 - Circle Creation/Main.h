/*----------------------------------------------
Programmer: Diana Diaz  (dxd9318@g.rit.edu)
Date: 2019/09
----------------------------------------------*/
#ifndef __MAIN_H_
#define __MAIN_H_
#include "AppClass.h"
#endif //__MAIN_H_

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/